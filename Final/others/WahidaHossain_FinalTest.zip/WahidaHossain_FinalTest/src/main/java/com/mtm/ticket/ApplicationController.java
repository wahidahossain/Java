package com.mtm.ticket;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import java.util.Optional;


@Controller
public class ApplicationController {
	
	private final BookServiceRepository bookServiceRepo;
	//private Movie movie;
	
	@RequestMapping("/")
    public String home()
    {
        return "index";
    }
	

	public ApplicationController(BookServiceRepository bookServiceRepo) {
		this.bookServiceRepo = bookServiceRepo;

	}
	
	
	@PostMapping("/saveBook")
    public String savePassenger(@ModelAttribute Book book, Model model)
    {	
		book.setBookId((int)(bookServiceRepo.count()+1));
		bookServiceRepo.save(book);
	    model.addAttribute("books", bookServiceRepo.findAll());
		return "allbooks";
		
    }
	

/*	 
	 @PostMapping("/createTicket")
    public String createTicket(@RequestParam String flightId, @RequestParam String departureDate, Model model)
    {
		 try {
			 Optional<Flight> selectedflight = flightService.find(flightId);
			 if (selectedflight.isPresent()) {
			 Ticket ticket = new Ticket(regPassenger.getPassengerId(),flightId,
							 new SimpleDateFormat("yyyy-MM-dd").parse(departureDate),
							 selectedflight.get().getPrice(),"Scheduled");
			 ticketService.create(ticket);
			 model.addAttribute("passenger", regPassenger);
			 model.addAttribute("flight", selectedflight.get());
			 model.addAttribute("ticket", ticket);
			 return "ticketConfirmation";
			 }
			 
			 } catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 	model.addAttribute("passenger", regPassenger);
		    model.addAttribute("flights", flightService.findAll());
			return "flights";
	 }

*/		 	
	    
}

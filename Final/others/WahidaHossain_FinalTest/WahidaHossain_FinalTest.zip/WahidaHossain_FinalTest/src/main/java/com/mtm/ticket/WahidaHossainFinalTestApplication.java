package com.mtm.ticket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WahidaHossainFinalTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(WahidaHossainFinalTestApplication.class, args);
	}

}
